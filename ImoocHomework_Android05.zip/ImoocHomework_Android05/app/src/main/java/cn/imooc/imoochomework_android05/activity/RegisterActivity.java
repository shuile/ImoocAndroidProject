package cn.imooc.imoochomework_android05.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import cn.imooc.imoochomework_android05.R;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }
}
