package com.imooc;

public interface IACT {

    /**
     * 描述技能
     */
    void skill();

    /**
     * 描述表演
     */
    void act();

}
