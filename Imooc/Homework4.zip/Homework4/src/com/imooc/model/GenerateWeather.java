package com.imooc.model;

//生成天气类
public class GenerateWeather implements Runnable {

    private Weather weather;

    public GenerateWeather(Weather weather) {
        this.weather = weather;
    }

    @Override
    public void run() {
        while (true) {
            weather.generate();
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
